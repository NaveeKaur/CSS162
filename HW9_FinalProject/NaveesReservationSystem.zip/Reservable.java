import java.util.*;
/**
 * The Reservable class represents an item that can be reserved.
 * Each Reservable will have 10 time slots that can be reserved
 * or requested by the user
 *
 * @author Created by Navee on 12/3/16.
 * @author Collaborated with Hanan Ibrahim
 */
public class Reservable {
    private String id;
    protected Reservation[] res = new Reservation[10];

    /**
     * Reads the next line from the Scanner of an input file.
     * The file has already been opened.
     * Extracts data for new item.
     * @param fileIn
     */
    public Reservable(Scanner fileIn) {
        if(fileIn.hasNext()) { id = fileIn.nextLine(); }
        else { id = null; }
    }

    /**
     * Another constructor to hold the String id.
     * @param id
     */
    public Reservable(String id) { this.id = id; }

    /**
     * Sets the reservation for an object.  
     */
    public void setReserve(int index, Reservation reserv) {
        this.res[index] = reserv;
    }
    
    /**
     *
     * @return ID that is extracted from the file.
     */
    public String getId() {
        return id;
    }

    /**
     * Returns an integer between 0 and 100 which tells the caller
     * how well fit a reservation is for this reservable item.
     * 0 means not at all fit.  100 means most fit.
     * @param r
     */
    public int findFitnessValue(Reservation r) {
        int timeslot = r.getReservationTime();
        if(res[timeslot] == null) { return 100; }
        else { return 0; }
    }

    /**
     * Return an iterator for all reservations for this reservable.
     */
    public Iterator<Reservation> getReservations() {
        List<Reservation> myList = Arrays.asList(res);
        return myList.iterator(); 
    }
}
