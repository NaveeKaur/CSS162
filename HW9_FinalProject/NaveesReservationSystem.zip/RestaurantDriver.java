import java.util.*; 
/**
 * The RestaurantDriver driver is a driver for the Restaurant System.
 * The Restaurant system reserves tables for a restaurant.  
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RestaurantDriver
{
    static ResManager<Table, Reservation> tableMgr = new ResManager<Table, Reservation>();

    /**
     * Asks the user for the reservation details (i.e. name, number people, and 
     * requested time. Then it makes these reservations using the Restaurant System,
     * and prints this out to the screen. 
     */
    public static void main(String[] args) {
        Scanner input = null; 
        Table table1 = new Table("blah", 1); 
        Table table2 = new Table("blah2", 2); 
        Table table3 = new Table("blah3", 3); 
        tableMgr.addReservable(table1); 
        tableMgr.addReservable(table2); 
        tableMgr.addReservable(table3); 

        input = new Scanner(System.in); 
        System.out.print("Enter your name: "); 
        String name = input.next(); 
        System.out.print("Enter the number of people in the party: "); 
        int num = input.nextInt(); 
        System.out.print("Enter the requested time slot, and press x to exit: "); 
        int time = input.nextInt(); 

        RestRes reservation = new RestRes(name, time, num); 
        tableMgr.makeReservation(reservation);  
        System.out.println(reservation); 

        if(input.next().equals("x") || input.next().equals("X")) {
            input.close(); 
        }
    }
}
