import java.util.*;
/**
 * TDerived from Reservable, The Hairdresser system tries 
 * to let the customer pick a number of hairdressers. 
 * The system will pick the first available hairdresser 
 * and use that Reservable in the reservation.
 * It represents a hairdresser; the ID of the Reservable 
 * is the name of the hairdresser. 
 * It does not need any new fields. 
 * 
 * Created by Navee on 12/14/16.
 */
public class HairDresser extends Reservable {
    /**
     * Reads a file from the parent class. 
     */
    public HairDresser(Scanner fileIn) { super(fileIn); }

    /**
     * Constructor that invokes the parent class. The ID of the Reservable
     * class is the name of the hairdresser. 
     */
    public HairDresser(String id) { super(id); }

    /** 
     * Finds the appropriate fitness value for the Appointment class. 
     */
    public int findFitnessValue(Reservation r) {
        int time = r.getReservationTime();
        if(r == null) { return 0; }
        else if (res[time] != null) { return 0; }
        else { return 100; }
    }
}
