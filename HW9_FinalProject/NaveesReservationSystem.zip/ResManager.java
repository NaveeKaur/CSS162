import java.util.*;
/**
 * The ResManager is a manager that holds a list of Reservables, active 
 * Reservations, and vends out iterators to the user. 
 * 
 * Created by Navee on 12/8/16.
 */
public class ResManager<I, R> {
    ArrayList<Reservable> resItem = new ArrayList<Reservable>();
    ArrayList<Reservation> reserv = new ArrayList<Reservation>();

    /**
     * No argument constructor.
     */
    public ResManager() {}

    /**
     * Adds an item to the manager.
     * @param item
     */
    public void addReservable(Reservable item) {
        if (item == null) {
            throw new IllegalArgumentException("Item not found. ");
        }
        else {
            resItem.add(item);
        }
    }

    /**
     * Attempts to take a reservation based on the info in trialRes.
     * If it fails returns null.
     * If it succeeds it returns the reservation and puts the reservation
     * in the internal ArrayList.
     *
     * Additionally, on success it sets the appropriate array entry in
     * Reservable, and sets the entry in the Reservation to point to its
     * Reservable.
     * @param trailRes
     * @return
     */
    public Reservation makeReservation(Reservation trailRes) {
        if(trailRes == null) {
            throw new IllegalArgumentException("Reservation not found. ");
        }
        else {
            reserv.add(trailRes);
            int index = highestFitnessVal(trailRes);
            Reservable bestMatch = resItem.get(index);
            int time = trailRes.getReservationTime();
            bestMatch.setReserve(time, trailRes);
            trailRes.setReservable(bestMatch);
            return trailRes; 
        }
    }

    /**
     * Get reservable by calling res.getReservable and set it to a variable
     * Remove thing from the resItem and remove res from reserv. 
     * Return the index in the reservable thing that contains your reservation. 
     */
    public boolean unreserve(Reservation res) {
        if(res == null) {
            return false; 
        }
        else {
            Reservable thing = res.getReservable(); 
            resItem.remove(thing); 
            reserv.remove(res); 
            int time = res.getReservationTime(); 
            thing.setReserve(time, null); 
            res.setReservable(null); 
            return true; 
        }
    }

    /**
     * Returns the highest fitness value.
     * @param trailRes
     */
    public int highestFitnessVal(Reservation trailRes) {
        ArrayList<Integer> fit = new ArrayList<Integer>();
        for (int i = 0; i< resItem.size(); i++) {
            Reservable thing = resItem.get(i);
            int val = thing.findFitnessValue(trailRes);
            fit.add(val);
        }
        return findMax(fit);
    }

    /**
     * Returns the highest fitness value in the ArrayList 
     * for highestFitnessValue.
     */
    public int findMax(ArrayList<Integer> array) {
        int max = Integer.MIN_VALUE;
        for(int i=0; i<array.size(); i++) {
            if(array.get(i) > max) {
                max = i; 
            }

        }
        return max; 
    }

}
