/**
 * The RestRest class is derived from Rservation and has an additional int
 * variable for the number of seats needed. Also represents request for a 
 * table at a specific timeslot. 
 * 
 * Created by Navee on 12/14/16.
 */
public class RestRes extends Reservation {
    int numSeatsNeeded;

    /**
     * Constructor that adds the name, seats, and time from parents class. 
     */
    public RestRes(String name, int time, int seats) {
        super(name, time);
        numSeatsNeeded = seats;
    }

    /**
     * Gets the number of seats needed for a reservation. 
     */
    public int getNumSeatsNeeded() {
        return numSeatsNeeded;
    }
}
