import java.util.*;
/**
 * The Table class is derived from Reservable and represents a table in the 
 * restaurant. It will have an additional integer variable for the number of
 * seats on the table. 
 * 
 * Created by Navee on 12/14/16.
 */
public class Table extends Reservable {
    int numSeats;

    /**
     * Constructor that reads from the Reservable class and adds thee number of 
     * seats at the table. 
     */
    public Table(Scanner inFile) {
        super(inFile);
        numSeats = inFile.nextInt();
    }

    /**
     * Constructor that calls the name from the Reservable class and adds seats. 
     */
    public Table(String id, int seats) {
        super(id);
        numSeats = seats;
    }

    /**
     *  Finds the appropriate fitness value so tables will be assigned appropriately.  
     *  i.e. Look for an available table which has the fewest number of extra seats.  
     *  This will be assigned the highest fitness value.
     */
    public int findFitnessValue(Reservation r) {
        if(!(r instanceof RestRes)) { 
            throw new IllegalArgumentException(); 
        }
        else {
            RestRes rs = (RestRes) r;
            int seats = rs.getNumSeatsNeeded();
            int time = rs.getReservationTime();
            if(rs == null) { return 0; }
            else if(numSeats < seats) { return 0; }
            else if (res[time] != null) {return 0; }
            else { return (100-(numSeats - seats)); }
        }
    }
}

