/**
 * The Reservation class represents a request by the user to
 * reserve an item and, if successful, represents the reservation
 * for the item.
 *
 * @author Created by Navee on 12/3/16.
 * @author Collaborated with Hanan Ibrahim
 */
public class Reservation {
    public String name;
    public int timeslot;
    private Reservable myReservable ;
    /**
     * Create a reservation request for a name and slot
     * @param name
     * @param timeslot
     */
    public Reservation(String name, int timeslot) {
        this.name = name;
        this.timeslot = timeslot;
    }

    /**
     * Set myReservable so that you can set the table.
     */
    public void setReservable(Reservable thing) {
        myReservable = thing;
    }
    
    public Reservable getReservable() {
        return myReservable; 
    }

    /**
     * @return Returns the name for reservation.
     *
     */
    public String getName() {
        return name;
    }

    /**
     * @return Returns the timeslot for reservation.
     *
     */
    public int getReservationTime() {
        return timeslot;
    }

    /**
     * @return Returns true if the reservation was successfully made.
     */
    public boolean isActive() {
        if(myReservable == null) { return false; }
        else {return true;}
    }

    /**
     *
     * @return String value of reservation.
     */
    public String toString() {
        String retVal = "Name: " + name + "\nTime Reserved: " + timeslot + "\nReservation Made?: " + this.isActive();
        return retVal;
    }
}
