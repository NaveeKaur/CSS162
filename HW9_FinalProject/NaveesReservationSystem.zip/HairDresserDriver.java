import java.util.*; 	
/**
 * The class HairDresserDriver makes an appointment for a hairdresser. It will 
 * allow the user to make reservations and request certain haidressers. 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HairDresserDriver
{
    /**
     * Asks for the user's name and requested time. Also asks for preffered 
     * hairdresser names. It will print these out to the screen. 
     */
    static ResManager<HairDresser, Reservation> dresserMgr = new ResManager<HairDresser, Reservation>();
    public static void main(String[] args) {
        Scanner input = null; 
        HairDresser dresser1 = new HairDresser("blah"); 
        HairDresser dresser2 = new HairDresser("blah2"); 
        HairDresser dresser3 = new HairDresser("blah3"); 
        dresserMgr.addReservable(dresser1); 
        dresserMgr.addReservable(dresser2); 
        dresserMgr.addReservable(dresser3); 

        input = new Scanner(System.in); 
        System.out.print("Enter your name: "); 
        String name = input.next(); 
        System.out.print("Enter the requested time slot: "); 
        int time = input.nextInt(); 
        System.out.println("Enter a list of preferred hairdressers: "); 
        String dresserNames = input.next(); 

        Appointment reservation = new Appointment(name, time); 
        reservation.addHairDresser(dresserNames); 	
        dresserMgr.makeReservation(reservation);  
        System.out.println(reservation); 

        if(input.next().equals("x") || input.next().equals("X")) {
            System.out.println("Ending."); 
            input.close(); 		
        }
    }
}
