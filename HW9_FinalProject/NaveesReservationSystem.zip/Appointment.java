import java.util.ArrayList;

/**
 * The Appointment class contains a list of possible hairdressers 
 * and desired time slots.It is derived from Reservation.java. 
 * It makes the hairdresser appointment. 
 * 
 * Created by Navee on 12/14/16.
 */
public class Appointment extends Reservation {
    ArrayList<String> dresserName = new ArrayList<String>();

    /**
     * Constructor to get the name and time from Reservation. 
     */
    public Appointment(String name, int time) {
        super(name, time);
    }

    /**
     * Adds a hairdresser name to an internal list in the Reservation. 
     * If hairdresser is active, this call will throw an Illegal Argument Exception. 
     */
    public void addHairDresser(String name) {
        if(super.isActive()) {
            throw new IllegalArgumentException(); 
        }
        dresserName.add(name);
    }

    /**
     * String that prints out the reservation details. 
     */
    public String toString() {
        String names = ""; 
        for(int i = 0; i < dresserName.size(); i++) {
            names = "" + dresserName; 
        }
        return "Name: "+ super.getName() + "\nTime: "+ super.getReservationTime() + "\nPreferred Hairdressers: " + names +"\nReservation Made?: " +this.isActive();   
    }
}
